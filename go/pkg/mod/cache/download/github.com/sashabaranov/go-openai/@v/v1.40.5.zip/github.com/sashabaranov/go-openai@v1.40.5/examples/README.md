To run an example:

```
export OPENAI_API_KEY="<your key here>"
go run ./example/<target>
```
